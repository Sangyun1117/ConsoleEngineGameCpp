#pragma once
#include "UI/UIElement.h"

//Todo: UI ����
class PlayerHpUI : UIElement {
	void Render() override;
};
