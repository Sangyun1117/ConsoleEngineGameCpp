#pragma once

//������
#define MAP_WIDTH 32
#define MAP_HEIGHT 16 

#define PLAYER_WIDTH 16
#define PLAYER_HEIGHT 10

#define BLOCKSIZE_WIDTH 10
#define BLOCKSIZE_HEIGHT 5

//������
#define ITEM_HAND 0
#define ITEM_PICKAXE 1
#define ITEM_SOARD 2
#define ITEM_GRASS_BLOCK 3