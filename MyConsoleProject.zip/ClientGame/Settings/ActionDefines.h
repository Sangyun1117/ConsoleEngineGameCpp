#pragma once

#define ACTION_IDLE     0
#define ACTION_ATTACK   20
#define ACTION_MOVE		40
#define ACTION_DIE      60